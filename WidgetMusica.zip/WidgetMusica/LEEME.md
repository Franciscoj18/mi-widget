# Mi Widget Musical 🎵

Widget para Android con controles de YouTube Music (⏮ ⏯ ⏭), nombre de la canción
y **una imagen de tu galería como portada**.

## Cómo obtener el APK

### Opción A — Con computadora (Android Studio)
1. Instala Android Studio (gratis).
2. File → Open → elige la carpeta `WidgetMusica`. Espera a que termine "Gradle sync".
3. Conecta tu Infinix por USB con la *Depuración USB* activada (Ajustes → Acerca del
   teléfono → toca 7 veces "Número de compilación" → Opciones de desarrollador).
4. Presiona ▶ Run. La app se instala sola.
   (O: Build → Build APK(s) y pasa el archivo `app-debug.apk` al teléfono.)

### Opción B — Sin computadora (GitHub, gratis)
1. Crea una cuenta en github.com y un repositorio nuevo.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`).
3. Ve a la pestaña **Actions**: se compila solo (2-4 minutos).
4. Abre la ejecución terminada → en *Artifacts* descarga `MiWidgetMusical-apk`,
   descomprímelo e instala `app-debug.apk` (permite "instalar apps desconocidas").

## Configuración en el teléfono
1. Abre **Mi Widget Musical**.
2. **Dar acceso a notificaciones** → activa Mi Widget Musical.
   - Si sale *"Configuración restringida"*: Ajustes → Apps → Mi Widget Musical →
     ⋮ → **Permitir configuración restringida**, y repite.
3. **Elegir imagen de la galería** → tu portada.
4. **Abrir ajustes de la app** → Batería → *Sin restricciones* y activa *Inicio automático*
   (XOS cierra apps en segundo plano y el widget se quedaría congelado).
5. Mantén presionada la pantalla de inicio → Widgets → **Mi Widget Musical** → arrástralo.

## Novedades v1.1
- Barra de progreso estilo Samsung (línea + bolita) con tiempo transcurrido y total.
- Editor de portada: mover, zoom con dos dedos, girar y brillo. El marco tiene la forma de tu widget.
- Si cambias el tamaño del widget, la imagen se vuelve a recortar sola.
- Controla la app que esté sonando (YouTube Music, Spotify, etc.) y abre esa misma app al tocar el widget.

## Cómo actualizar
1. En GitHub: Add file → Upload files → sube el nuevo `WidgetMusica.zip` (reemplaza el anterior) → Commit.
2. Actions compila solo; descarga el nuevo APK de Artifacts.
3. Solo esta vez: desinstala la versión anterior antes de instalar (cambió la firma).
   Desde la v1.1 las siguientes actualizaciones se instalan encima.

## Cómo funciona
- Tocar ⏮ ⏯ ⏭ controla YouTube Music (o la app de música que esté sonando).
- Tocar la imagen abre YouTube Music.
- Para cambiar la portada: abre la app, o mantén presionado el widget → Reconfigurar.
- "Usar la portada de la canción" quita tu imagen y muestra la del álbum.
