package com.miwidget.musica

import android.app.Activity
import android.media.MediaMetadata
import android.media.session.MediaController
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.format.DateUtils
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Ventanita flotante con una barra que sí se puede arrastrar para elegir el punto exacto. */
class SeekActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private var duration = 0L
    private var dragging = false

    private lateinit var seek: SeekBar
    private lateinit var elapsed: TextView
    private lateinit var total: TextView
    private lateinit var title: TextView
    private lateinit var artist: TextView

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seek)
        setFinishOnTouchOutside(true)

        seek = findViewById(R.id.seek)
        elapsed = findViewById(R.id.seek_elapsed)
        total = findViewById(R.id.seek_total)
        title = findViewById(R.id.seek_title)
        artist = findViewById(R.id.seek_artist)

        controller = WidgetUpdater.findController(this)
        duration = controller?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (controller == null || duration <= 0L) {
            Toast.makeText(this, "No hay una canción que se pueda adelantar", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        seek.max = 1000
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) elapsed.text = format(duration * progress / 1000)
            }
            override fun onStartTrackingTouch(bar: SeekBar) {
                dragging = true
            }
            override fun onStopTrackingTouch(bar: SeekBar) {
                seekTo(duration * bar.progress / 1000)
                dragging = false
            }
        })

        findViewById<Button>(R.id.btn_back10).setOnClickListener { jump(-10_000) }
        findViewById<Button>(R.id.btn_fwd10).setOnClickListener { jump(10_000) }
        findViewById<Button>(R.id.btn_close).setOnClickListener { finish() }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        WidgetUpdater.updateAll(applicationContext)
        super.onDestroy()
    }

    private fun currentPos(): Long {
        val state = controller?.playbackState ?: return 0L
        return WidgetUpdater.currentPosition(state).coerceIn(0L, duration)
    }

    private fun refresh() {
        val c = controller ?: return
        // Si cambió la canción, tomamos la nueva duración
        val meta = c.metadata
        duration = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.takeIf { it > 0 } ?: duration
        title.text = meta?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Música"
        artist.text = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        total.text = format(duration)
        if (!dragging) {
            val pos = currentPos()
            seek.progress = (pos * 1000 / duration).toInt()
            elapsed.text = format(pos)
        }
    }

    private fun jump(deltaMs: Long) {
        seekTo((currentPos() + deltaMs).coerceIn(0L, duration))
    }

    private fun seekTo(ms: Long) {
        controller?.transportControls?.seekTo(ms)
        elapsed.text = format(ms)
        seek.progress = (ms * 1000 / duration).toInt()
        handler.postDelayed({ WidgetUpdater.updateAll(applicationContext) }, 350)
    }

    private fun format(ms: Long) = DateUtils.formatElapsedTime(ms / 1000)
}
