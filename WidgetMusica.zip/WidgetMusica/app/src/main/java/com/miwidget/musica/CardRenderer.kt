package com.miwidget.musica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Dibuja la "tarjeta" del widget como una sola imagen: portada + degradado oscuro
 * + esquinas redondeadas + sombra. Al hacerlo en la imagen, las esquinas y la sombra
 * se ven igual en cualquier launcher y en cualquier versión de Android (incluido Android 11).
 */
object CardRenderer {

    // Margen transparente alrededor de la tarjeta, donde cae la sombra (en dp).
    // Deben coincidir con los márgenes de widget_music.xml.
    const val INSET_SIDE = 8f
    const val INSET_TOP = 6f
    const val INSET_BOTTOM = 10f

    fun render(ctx: Context, source: Bitmap?, wDp: Float, hDp: Float): Bitmap {
        val density = ctx.resources.displayMetrics.density
        val s = min(density, 1000f / wDp)          // píxeles por dp, con tope de tamaño
        val w = (wDp * s).roundToInt().coerceAtLeast(1)
        val h = (hDp * s).roundToInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        val card = RectF(INSET_SIDE * s, INSET_TOP * s, w - INSET_SIDE * s, h - INSET_BOTTOM * s)
        if (card.width() < 2f || card.height() < 2f) return out
        val radius = (StyleStore.radiusDp(ctx) * s).coerceAtMost(min(card.width(), card.height()) / 2f)

        // 1) Sombra suave debajo de la tarjeta
        if (StyleStore.shadow(ctx)) {
            val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                setShadowLayer(7f * s, 0f, 3f * s, 0x73000000)
            }
            canvas.drawRoundRect(card, radius, radius, shadowPaint)
        }

        // 2) Contenido: portada recortada al centro + degradado para leer el texto
        val cw = card.width().roundToInt().coerceAtLeast(1)
        val ch = card.height().roundToInt().coerceAtLeast(1)
        val content = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val cc = Canvas(content)
        if (source != null) drawCenterCrop(cc, source, cw.toFloat(), ch.toFloat())
        else drawPlaceholder(cc, cw.toFloat(), ch.toFloat())
        val scrim = Paint().apply {
            shader = LinearGradient(
                0f, 0f, 0f, ch.toFloat(),
                intArrayOf(0x00000000, 0x40000000, 0xD9000000.toInt()),
                floatArrayOf(0.30f, 0.60f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        cc.drawRect(0f, 0f, cw.toFloat(), ch.toFloat(), scrim)

        // 3) Pegamos el contenido con esquinas redondeadas y suavizadas
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            shader = BitmapShader(content, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).apply {
                setLocalMatrix(Matrix().apply { setTranslate(card.left, card.top) })
            }
        }
        canvas.drawRoundRect(card, radius, radius, cardPaint)
        content.recycle()
        return out
    }

    private fun drawCenterCrop(c: Canvas, src: Bitmap, w: Float, h: Float) {
        val scale = max(w / src.width, h / src.height)
        val dw = src.width * scale
        val dh = src.height * scale
        val left = (w - dw) / 2f
        val top = (h - dh) / 2f
        c.drawBitmap(src, null, RectF(left, top, left + dw, top + dh), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    private fun drawPlaceholder(c: Canvas, w: Float, h: Float) {
        val p = Paint().apply {
            shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(0xFFFF0033.toInt(), 0xFF8E2DE2.toInt(), 0xFF1A1A2E.toInt()),
                null, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, w, h, p)
    }

    /**
     * Color principal de la imagen (el más vivo y abundante), ajustado para que
     * se vea bien sobre el fondo oscuro. Si la imagen es gris, devuelve blanco.
     */
    fun accentFrom(src: Bitmap?): Int {
        if (src == null) return Color.WHITE
        val small = Bitmap.createScaledBitmap(src, 24, 24, true)
        val weights = FloatArray(12)
        val sumR = FloatArray(12)
        val sumG = FloatArray(12)
        val sumB = FloatArray(12)
        val hsv = FloatArray(3)
        for (y in 0 until small.height) {
            for (x in 0 until small.width) {
                val px = small.getPixel(x, y)
                Color.colorToHSV(px, hsv)
                if (hsv[1] < 0.2f || hsv[2] < 0.25f) continue
                val weight = hsv[1] * hsv[2]
                val bin = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                weights[bin] += weight
                sumR[bin] += Color.red(px) * weight
                sumG[bin] += Color.green(px) * weight
                sumB[bin] += Color.blue(px) * weight
            }
        }
        if (small != src) small.recycle()
        var best = 0
        for (i in 1 until 12) if (weights[i] > weights[best]) best = i
        val total = weights[best]
        if (total < 4f) return Color.WHITE
        val avg = Color.rgb(
            (sumR[best] / total).roundToInt().coerceIn(0, 255),
            (sumG[best] / total).roundToInt().coerceIn(0, 255),
            (sumB[best] / total).roundToInt().coerceIn(0, 255)
        )
        Color.colorToHSV(avg, hsv)
        hsv[1] = hsv[1].coerceIn(0.35f, 0.75f)
        hsv[2] = max(hsv[2], 0.92f)
        return Color.HSVToColor(hsv)
    }

    /** Negro o blanco, lo que se lea mejor sobre [bg]. */
    fun contentColorFor(bg: Int): Int =
        if (Color.luminance(bg) > 0.5f) Color.BLACK else Color.WHITE
}
