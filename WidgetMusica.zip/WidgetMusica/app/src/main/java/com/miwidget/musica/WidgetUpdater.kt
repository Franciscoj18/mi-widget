package com.miwidget.musica

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.provider.Settings
import android.view.KeyEvent
import android.widget.RemoteViews
import kotlin.math.max

/** Toda la lógica para encontrar YouTube Music, controlarlo y dibujar el widget. */
object WidgetUpdater {

    const val YT_MUSIC = "com.google.android.apps.youtube.music"

    const val ACTION_PREV = "com.miwidget.musica.PREV"
    const val ACTION_PLAY_PAUSE = "com.miwidget.musica.PLAY_PAUSE"
    const val ACTION_NEXT = "com.miwidget.musica.NEXT"

    /** ¿El usuario ya activó el "Acceso a notificaciones" para esta app? */
    fun hasNotificationAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(":").any {
            ComponentName.unflattenFromString(it)?.packageName == ctx.packageName
        }
    }

    /** Busca la sesión de YouTube Music; si no hay, usa la app de música activa. */
    fun findController(ctx: Context): MediaController? {
        if (!hasNotificationAccess(ctx)) return null
        val msm = ctx.getSystemService(MediaSessionManager::class.java) ?: return null
        val sessions: List<MediaController> = try {
            msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
        } catch (e: SecurityException) {
            return null
        }
        return sessions.firstOrNull { it.packageName == YT_MUSIC }
            ?: sessions.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: sessions.firstOrNull()
    }

    private fun isPlaying(c: MediaController?): Boolean {
        val s = c?.playbackState?.state ?: return false
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    /** Ejecuta el botón presionado en el widget. */
    fun handleAction(ctx: Context, action: String) {
        val controller = findController(ctx)
        if (controller != null) {
            val t = controller.transportControls
            when (action) {
                ACTION_PREV -> t.skipToPrevious()
                ACTION_NEXT -> t.skipToNext()
                ACTION_PLAY_PAUSE -> if (isPlaying(controller)) t.pause() else t.play()
            }
        } else {
            // Sin sesión activa: mandamos la tecla multimedia (reanuda la última app de música)
            val am = ctx.getSystemService(AudioManager::class.java) ?: return
            val code = when (action) {
                ACTION_PREV -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                ACTION_NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
                else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }

    /** Redibuja todos los widgets que el usuario tenga en su pantalla. */
    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, MusicWidgetProvider::class.java))
        if (ids.isEmpty()) return
        mgr.updateAppWidget(ids, buildViews(ctx))
    }

    private fun buildViews(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_music)
        val hasAccess = hasNotificationAccess(ctx)
        val controller = findController(ctx)
        val meta = controller?.metadata

        // --- Textos ---
        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)

        when {
            !hasAccess -> {
                rv.setTextViewText(R.id.title, "Toca para configurar")
                rv.setTextViewText(R.id.artist, "Falta dar acceso a la música")
            }
            title.isNullOrBlank() -> {
                rv.setTextViewText(R.id.title, "YouTube Music")
                rv.setTextViewText(R.id.artist, "Nada reproduciéndose")
            }
            else -> {
                rv.setTextViewText(R.id.title, title)
                rv.setTextViewText(R.id.artist, artist ?: "")
            }
        }

        // --- Botón play / pausa ---
        rv.setImageViewResource(
            R.id.btn_play,
            if (isPlaying(controller)) R.drawable.ic_pause_dark else R.drawable.ic_play_dark
        )

        // --- Portada: primero TU imagen; si no elegiste, la del álbum ---
        val cover: Bitmap? = CoverStore.load(ctx) ?: albumArt(meta)
        if (cover != null) rv.setImageViewBitmap(R.id.cover, cover)
        else rv.setImageViewResource(R.id.cover, R.drawable.cover_placeholder)

        // --- Botones ---
        rv.setOnClickPendingIntent(R.id.btn_prev, actionIntent(ctx, ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.btn_play, actionIntent(ctx, ACTION_PLAY_PAUSE, 2))
        rv.setOnClickPendingIntent(R.id.btn_next, actionIntent(ctx, ACTION_NEXT, 3))

        // Tocar el resto del widget: abre YouTube Music (o la configuración si falta algo)
        val openIntent = if (hasAccess) {
            ctx.packageManager.getLaunchIntentForPackage(YT_MUSIC)
                ?: Intent(ctx, ConfigActivity::class.java)
        } else {
            Intent(ctx, ConfigActivity::class.java)
        }
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        rv.setOnClickPendingIntent(
            R.id.root,
            PendingIntent.getActivity(
                ctx, 10, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        return rv
    }

    private fun albumArt(meta: MediaMetadata?): Bitmap? {
        if (meta == null) return null
        val art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            ?: return null
        val maxSide = max(art.width, art.height)
        if (maxSide <= 600) return art
        val scale = 600f / maxSide
        return Bitmap.createScaledBitmap(
            art, (art.width * scale).toInt().coerceAtLeast(1),
            (art.height * scale).toInt().coerceAtLeast(1), true
        )
    }

    private fun actionIntent(ctx: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(ctx, MusicWidgetProvider::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
