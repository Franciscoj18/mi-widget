package com.miwidget.musica

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.text.format.DateUtils
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.widget.RemoteViews
import kotlin.math.max

/** Toda la lógica para encontrar el reproductor, controlarlo y dibujar el widget. */
object WidgetUpdater {

    const val YT_MUSIC = "com.google.android.apps.youtube.music"

    const val ACTION_PREV = "com.miwidget.musica.PREV"
    const val ACTION_PLAY_PAUSE = "com.miwidget.musica.PLAY_PAUSE"
    const val ACTION_NEXT = "com.miwidget.musica.NEXT"
    const val ACTION_SEEK = "com.miwidget.musica.SEEK"
    const val EXTRA_FRACTION = "fraction"

    private const val ZONES = 20
    private val SEEK_ZONES = intArrayOf(
        R.id.seek_0, R.id.seek_1, R.id.seek_2, R.id.seek_3, R.id.seek_4, R.id.seek_5, R.id.seek_6, R.id.seek_7, R.id.seek_8, R.id.seek_9, R.id.seek_10, R.id.seek_11, R.id.seek_12, R.id.seek_13, R.id.seek_14, R.id.seek_15, R.id.seek_16, R.id.seek_17, R.id.seek_18, R.id.seek_19
    )

    /** ¿El usuario ya activó el "Acceso a notificaciones" para esta app? */
    fun hasNotificationAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(":").any {
            ComponentName.unflattenFromString(it)?.packageName == ctx.packageName
        }
    }

    /**
     * Elige qué reproductor controlar: el que esté sonando ahora (YouTube Music, Spotify…);
     * si ninguno suena, YouTube Music; si no, el último activo.
     */
    fun findController(ctx: Context): MediaController? {
        if (!hasNotificationAccess(ctx)) return null
        val msm = ctx.getSystemService(MediaSessionManager::class.java) ?: return null
        val sessions: List<MediaController> = try {
            msm.getActiveSessions(ComponentName(ctx, MediaListenerService::class.java))
        } catch (e: SecurityException) {
            return null
        }
        return sessions.firstOrNull { isPlaying(it) }
            ?: sessions.firstOrNull { it.packageName == YT_MUSIC }
            ?: sessions.firstOrNull()
    }

    fun isPlaying(c: MediaController?): Boolean {
        val s = c?.playbackState?.state ?: return false
        return s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_BUFFERING
    }

    /** Salta a una fracción (0..1) de la canción. */
    fun seekToFraction(ctx: Context, fraction: Float) {
        val c = findController(ctx) ?: return
        val duration = c.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: return
        if (duration <= 0L) return
        c.transportControls.seekTo((duration * fraction.coerceIn(0f, 1f)).toLong())
    }

    /** Ejecuta el botón presionado en el widget. */
    fun handleAction(ctx: Context, action: String) {
        val controller = findController(ctx)
        if (controller != null) {
            val t = controller.transportControls
            when (action) {
                ACTION_PREV -> t.skipToPrevious()
                ACTION_NEXT -> t.skipToNext()
                ACTION_PLAY_PAUSE -> if (isPlaying(controller)) t.pause() else t.play()
            }
        } else {
            // Sin sesión activa: mandamos la tecla multimedia (reanuda la última app de música)
            val am = ctx.getSystemService(AudioManager::class.java) ?: return
            val code = when (action) {
                ACTION_PREV -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                ACTION_NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
                else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            }
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        }
    }

    private fun widgetIds(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx)
            .getAppWidgetIds(ComponentName(ctx, MusicWidgetProvider::class.java))

    /** Redibuja todos los widgets (portada, textos, botones y barra). */
    fun updateAll(ctx: Context) {
        val ids = widgetIds(ctx)
        if (ids.isEmpty()) return
        AppWidgetManager.getInstance(ctx).updateAppWidget(ids, buildViews(ctx))
    }

    /** Actualización ligera, solo la barra de progreso y el tiempo (se llama cada segundo). */
    fun updateProgress(ctx: Context, controller: MediaController?) {
        val ids = widgetIds(ctx)
        if (ids.isEmpty()) return
        val rv = RemoteViews(ctx.packageName, R.layout.widget_music)
        applyProgress(ctx, rv, controller)
        AppWidgetManager.getInstance(ctx).partiallyUpdateAppWidget(ids, rv)
    }

    /** Posición actual de la canción en milisegundos, calculada al momento. */
    fun currentPosition(state: PlaybackState): Long {
        var pos = state.position
        if (state.state == PlaybackState.STATE_PLAYING && state.lastPositionUpdateTime > 0) {
            val delta = SystemClock.elapsedRealtime() - state.lastPositionUpdateTime
            pos += (delta * state.playbackSpeed).toLong()
        }
        return pos
    }

    /** Ancho aproximado de la barra en dp (ancho del widget menos los márgenes). */
    private fun barWidthDp(ctx: Context): Float {
        val mgr = AppWidgetManager.getInstance(ctx)
        for (id in widgetIds(ctx)) {
            val w = mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            if (w > 0) return (w - 32).toFloat().coerceAtLeast(60f)
        }
        return 280f
    }

    private fun applyProgress(ctx: Context, rv: RemoteViews, controller: MediaController?) {
        val duration = controller?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val state = controller?.playbackState
        if (duration <= 0L || state == null) {
            rv.setViewVisibility(R.id.progress_group, View.GONE)
            return
        }
        val pos = currentPosition(state).coerceIn(0L, duration)
        val fraction = pos.toFloat() / duration
        val playing = isPlaying(controller)
        rv.setViewVisibility(R.id.progress_group, View.VISIBLE)

        if (Build.VERSION.SDK_INT >= 31) {
            // Ola animada: se recorta al ancho de lo ya escuchado
            val dip = TypedValue.COMPLEX_UNIT_DIP
            val w = barWidthDp(ctx)
            val played = w * fraction
            rv.setViewVisibility(R.id.progress, View.GONE)
            rv.setViewLayoutWidth(R.id.wave, w, dip)
            rv.setViewLayoutWidth(R.id.played_clip, played, dip)
            rv.setViewLayoutMargin(R.id.track_rest, RemoteViews.MARGIN_START, played, dip)
            rv.setViewLayoutMargin(R.id.thumb, RemoteViews.MARGIN_START, (played - 6f).coerceAtLeast(0f), dip)
            // Suena: ola en movimiento. Pausa: línea recta.
            rv.setViewVisibility(R.id.wave, if (playing) View.VISIBLE else View.GONE)
            rv.setViewVisibility(R.id.played_flat, if (playing) View.GONE else View.VISIBLE)
        } else {
            // Android 11 o anterior: barra simple
            rv.setViewVisibility(R.id.progress, View.VISIBLE)
            rv.setViewVisibility(R.id.track_rest, View.GONE)
            rv.setViewVisibility(R.id.played_clip, View.GONE)
            rv.setViewVisibility(R.id.thumb, View.GONE)
            rv.setProgressBar(R.id.progress, 1000, (fraction * 1000).toInt(), false)
        }

        // El cronómetro avanza solo, segundo a segundo, mientras suena
        rv.setChronometer(R.id.elapsed, SystemClock.elapsedRealtime() - pos, null, playing)
        rv.setTextViewText(R.id.total, DateUtils.formatElapsedTime(duration / 1000))
    }

    private fun buildViews(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_music)
        val hasAccess = hasNotificationAccess(ctx)
        val controller = findController(ctx)
        val meta = controller?.metadata

        // --- Textos ---
        val title = meta?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
        val artist = meta?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: meta?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)

        when {
            !hasAccess -> {
                rv.setTextViewText(R.id.title, "Toca para configurar")
                rv.setTextViewText(R.id.artist, "Falta dar acceso a la música")
            }
            title.isNullOrBlank() -> {
                rv.setTextViewText(R.id.title, "Música")
                rv.setTextViewText(R.id.artist, "Nada reproduciéndose")
            }
            else -> {
                rv.setTextViewText(R.id.title, title)
                rv.setTextViewText(R.id.artist, artist ?: "")
            }
        }

        // --- Barra de progreso ---
        applyProgress(ctx, rv, controller)

        // --- Botón play / pausa ---
        rv.setImageViewResource(
            R.id.btn_play,
            if (isPlaying(controller)) R.drawable.ic_pause_dark else R.drawable.ic_play_dark
        )

        // --- Portada: primero TU imagen ajustada; si no elegiste, la del álbum ---
        val cover: Bitmap? = CoverStore.load(ctx) ?: albumArt(meta)
        if (cover != null) rv.setImageViewBitmap(R.id.cover, cover)
        else rv.setImageViewResource(R.id.cover, R.drawable.cover_placeholder)

        // --- Botones ---
        rv.setOnClickPendingIntent(R.id.btn_prev, actionIntent(ctx, ACTION_PREV, 1))
        rv.setOnClickPendingIntent(R.id.btn_play, actionIntent(ctx, ACTION_PLAY_PAUSE, 2))
        rv.setOnClickPendingIntent(R.id.btn_next, actionIntent(ctx, ACTION_NEXT, 3))

        // Tocar la barra: salta a ese punto
        for (i in 0 until ZONES) {
            val fraction = (i + 0.5f) / ZONES
            val intent = Intent(ctx, MusicWidgetProvider::class.java)
                .setAction(ACTION_SEEK)
                .putExtra(EXTRA_FRACTION, fraction)
            rv.setOnClickPendingIntent(
                SEEK_ZONES[i],
                PendingIntent.getBroadcast(
                    ctx, 100 + i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            )
        }

        // Tocar los tiempos: abre la ventanita para arrastrar con precisión
        val seekDialog = Intent(ctx, SeekActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        rv.setOnClickPendingIntent(
            R.id.times_row,
            PendingIntent.getActivity(
                ctx, 20, seekDialog,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )

        // Tocar el resto del widget: abre la app que está sonando (o YouTube Music)
        val pm = ctx.packageManager
        val openIntent = if (hasAccess) {
            controller?.packageName?.let { pm.getLaunchIntentForPackage(it) }
                ?: pm.getLaunchIntentForPackage(YT_MUSIC)
                ?: Intent(ctx, ConfigActivity::class.java)
        } else {
            Intent(ctx, ConfigActivity::class.java)
        }
        openIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        rv.setOnClickPendingIntent(
            R.id.root,
            PendingIntent.getActivity(
                ctx, 10, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        )
        return rv
    }

    private fun albumArt(meta: MediaMetadata?): Bitmap? {
        if (meta == null) return null
        val art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            ?: return null
        val maxSide = max(art.width, art.height)
        if (maxSide <= 600) return art
        val scale = 600f / maxSide
        return Bitmap.createScaledBitmap(
            art, (art.width * scale).toInt().coerceAtLeast(1),
            (art.height * scale).toInt().coerceAtLeast(1), true
        )
    }

    private fun actionIntent(ctx: Context, action: String, code: Int): PendingIntent {
        val intent = Intent(ctx, MusicWidgetProvider::class.java).setAction(action)
        return PendingIntent.getBroadcast(
            ctx, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
