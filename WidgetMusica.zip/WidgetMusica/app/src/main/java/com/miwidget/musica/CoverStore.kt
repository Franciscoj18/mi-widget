package com.miwidget.musica

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Guarda la imagen original que eligió el usuario y cómo la ajustó
 * (posición, zoom, brillo). A partir de eso "recorta" la portada final del widget.
 */
object CoverStore {

    private const val ORIGINAL_MAX = 1600 // px
    private const val COVER_MAX = 1000    // px
    private const val PREFS = "cover_prefs"

    /** Ajustes del usuario. cx/cy = centro del recorte (0..1), zoom >= 1, brillo 0.5..1.5 */
    data class Params(val cx: Float, val cy: Float, val zoom: Float, val brightness: Float)

    private fun originalFile(ctx: Context) = File(ctx.filesDir, "original.jpg")
    private fun coverFile(ctx: Context) = File(ctx.filesDir, "cover.jpg")

    fun hasOriginal(ctx: Context) = originalFile(ctx).exists()
    fun hasCover(ctx: Context) = coverFile(ctx).exists()

    // ---------- Ajustes ----------

    fun loadParams(ctx: Context): Params {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Params(
            p.getFloat("cx", 0.5f), p.getFloat("cy", 0.5f),
            p.getFloat("zoom", 1f), p.getFloat("brightness", 1f)
        )
    }

    fun saveParams(ctx: Context, params: Params) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat("cx", params.cx).putFloat("cy", params.cy)
            .putFloat("zoom", params.zoom).putFloat("brightness", params.brightness)
            .apply()
    }

    private fun resetParams(ctx: Context) = saveParams(ctx, Params(0.5f, 0.5f, 1f, 1f))

    // ---------- Imagen original ----------

    /** Copia la imagen elegida de la galería (ya rotada según la foto y reducida). */
    fun importOriginal(ctx: Context, uri: Uri): Boolean {
        return try {
            val source = ImageDecoder.createSource(ctx.contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val scale = min(1f, ORIGINAL_MAX / max(w, h).toFloat())
                decoder.setTargetSize(max(1, (w * scale).toInt()), max(1, (h * scale).toInt()))
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            writeJpeg(bitmap, originalFile(ctx))
            resetParams(ctx)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun loadOriginal(ctx: Context): Bitmap? = decode(originalFile(ctx))

    /** Gira la imagen original 90° a la derecha. */
    fun rotateOriginal(ctx: Context): Boolean {
        val src = loadOriginal(ctx) ?: return false
        val m = Matrix().apply { postRotate(90f) }
        val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        writeJpeg(rotated, originalFile(ctx))
        resetParams(ctx)
        return true
    }

    // ---------- Portada final ----------

    fun load(ctx: Context): Bitmap? = decode(coverFile(ctx))

    fun clear(ctx: Context) {
        coverFile(ctx).delete()
        originalFile(ctx).delete()
        resetParams(ctx)
    }

    /** Rectángulo de la imagen original que se verá, para un widget de proporción [aspect] (ancho/alto). */
    fun cropRect(imgW: Float, imgH: Float, aspect: Float, p: Params): RectF {
        val baseW: Float
        val baseH: Float
        if (imgW / imgH > aspect) {
            baseH = imgH; baseW = imgH * aspect
        } else {
            baseW = imgW; baseH = imgW / aspect
        }
        val w = baseW / p.zoom
        val h = baseH / p.zoom
        val cx = clamp(p.cx * imgW, w / 2, imgW - w / 2)
        val cy = clamp(p.cy * imgH, h / 2, imgH - h / 2)
        return RectF(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
    }

    private fun clamp(v: Float, lo: Float, hi: Float) =
        if (lo > hi) (lo + hi) / 2 else v.coerceIn(lo, hi)

    fun brightnessPaint(f: Float): Paint {
        val cm = ColorMatrix(
            floatArrayOf(
                f, 0f, 0f, 0f, 0f,
                0f, f, 0f, 0f, 0f,
                0f, 0f, f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        return Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
    }

    /** Genera cover.jpg con el recorte, zoom y brillo que eligió el usuario. */
    fun renderCover(ctx: Context, aspect: Float): Boolean {
        val src = loadOriginal(ctx) ?: return false
        val p = loadParams(ctx)
        val r = cropRect(src.width.toFloat(), src.height.toFloat(), aspect, p)
        val outW: Int
        val outH: Int
        if (aspect >= 1f) {
            outW = min(COVER_MAX, r.width().roundToInt()).coerceAtLeast(1)
            outH = (outW / aspect).roundToInt().coerceAtLeast(1)
        } else {
            outH = min(COVER_MAX, r.height().roundToInt()).coerceAtLeast(1)
            outW = (outH * aspect).roundToInt().coerceAtLeast(1)
        }
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(
            src,
            Rect(r.left.roundToInt(), r.top.roundToInt(), r.right.roundToInt(), r.bottom.roundToInt()),
            Rect(0, 0, outW, outH),
            brightnessPaint(p.brightness)
        )
        writeJpeg(out, coverFile(ctx))
        return true
    }

    /** Proporción (ancho/alto) del widget que el usuario tiene en su pantalla. */
    fun widgetAspect(ctx: Context): Float {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, MusicWidgetProvider::class.java))
        for (id in ids) {
            val o = mgr.getAppWidgetOptions(id)
            val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
            val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
            if (w > 0 && h > 0) return w.toFloat() / h
        }
        return 2f // widget 4x2 típico
    }

    // ---------- Utilidades ----------

    private fun decode(f: File): Bitmap? {
        if (!f.exists()) return null
        return try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
    }

    /** Escribe primero a un temporal y luego renombra, para que el widget nunca lea un archivo a medias. */
    private fun writeJpeg(bitmap: Bitmap, target: File) {
        val tmp = File(target.parentFile, target.name + ".tmp")
        FileOutputStream(tmp).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        tmp.renameTo(target)
    }
}
