package com.miwidget.musica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

/** Guarda y lee la imagen de portada que eligió el usuario de su galería. */
object CoverStore {

    private const val MAX_SIZE = 900 // px, suficiente para un widget y ligero

    private fun file(ctx: Context) = File(ctx.filesDir, "cover.jpg")

    fun hasCover(ctx: Context) = file(ctx).exists()

    /** Copia la imagen elegida (ya rotada y reducida) a la memoria interna de la app. */
    fun save(ctx: Context, uri: Uri): Boolean {
        return try {
            val source = ImageDecoder.createSource(ctx.contentResolver, uri)
            val bitmap = ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val scale = min(1f, MAX_SIZE / max(w, h).toFloat())
                decoder.setTargetSize(max(1, (w * scale).toInt()), max(1, (h * scale).toInt()))
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
            FileOutputStream(file(ctx)).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
    }

    fun clear(ctx: Context) {
        file(ctx).delete()
    }
}
