package com.miwidget.musica

import android.content.Context

/** Preferencias de estilo del widget: curvatura de bordes, sombra y color automático. */
object StyleStore {

    private const val PREFS = "style_prefs"
    const val MAX_RADIUS = 40

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun radiusDp(ctx: Context) = prefs(ctx).getInt("radius", 28)
    fun shadow(ctx: Context) = prefs(ctx).getBoolean("shadow", true)
    fun autoColor(ctx: Context) = prefs(ctx).getBoolean("auto_color", true)

    fun setRadiusDp(ctx: Context, v: Int) =
        prefs(ctx).edit().putInt("radius", v.coerceIn(0, MAX_RADIUS)).apply()

    fun setShadow(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("shadow", v).apply()
    fun setAutoColor(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("auto_color", v).apply()

    /** Cambia cuando cambia algo que afecta cómo se dibuja la tarjeta. */
    fun signature(ctx: Context) = "${radiusDp(ctx)}-${shadow(ctx)}"
}
