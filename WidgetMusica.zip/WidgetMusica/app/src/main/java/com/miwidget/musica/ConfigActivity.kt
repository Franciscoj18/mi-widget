package com.miwidget.musica

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

/** Pantalla para dar permisos y elegir la imagen de portada. */
class ConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var preview: ImageView
    private lateinit var permStatus: TextView
    private lateinit var btnPermission: Button
    private lateinit var btnClear: Button
    private lateinit var btnAdjust: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        // Aunque salgas con "atrás", el widget se agrega igual
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) setResult(RESULT_OK, resultIntent())

        preview = findViewById(R.id.preview)
        permStatus = findViewById(R.id.perm_status)
        btnPermission = findViewById(R.id.btn_permission)
        btnClear = findViewById(R.id.btn_clear)

        btnPermission.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.btn_pick).setOnClickListener { pickImage() }
        btnAdjust = findViewById(R.id.btn_adjust)
        btnAdjust.setOnClickListener { startActivity(Intent(this, CropActivity::class.java)) }
        btnClear.setOnClickListener {
            CoverStore.clear(this)
            WidgetUpdater.updateAll(this)
            refreshUi()
            Toast.makeText(this, "Ahora se mostrará la portada de la canción", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btn_battery).setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:$packageName"))
            )
        }
        findViewById<Button>(R.id.btn_done).setOnClickListener {
            WidgetUpdater.updateAll(this)
            if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) setResult(RESULT_OK, resultIntent())
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        MediaListenerService.rebindIfNeeded(this)
        refreshUi()
        WidgetUpdater.updateAll(this)
    }

    private fun refreshUi() {
        val ok = WidgetUpdater.hasNotificationAccess(this)
        permStatus.text = if (ok) "✅ Acceso a la música activado"
        else "⚠️ Falta dar acceso para leer y controlar YouTube Music"
        btnPermission.visibility = if (ok) View.GONE else View.VISIBLE

        val cover = CoverStore.load(this)
        if (cover != null) preview.setImageBitmap(cover)
        else preview.setImageResource(R.drawable.cover_placeholder)
        btnClear.visibility = if (CoverStore.hasCover(this)) View.VISIBLE else View.GONE
        btnAdjust.visibility = if (CoverStore.hasOriginal(this)) View.VISIBLE else View.GONE
    }

    private fun pickImage() {
        val fallback = Intent(Intent.ACTION_GET_CONTENT)
            .setType("image/*")
            .addCategory(Intent.CATEGORY_OPENABLE)
        val intent = if (Build.VERSION.SDK_INT >= 33) Intent(MediaStore.ACTION_PICK_IMAGES) else fallback
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: ActivityNotFoundException) {
            startActivityForResult(fallback, REQ_PICK)
        }
    }

    @Deprecated("API clásica, suficiente aquí")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        Toast.makeText(this, "Cargando imagen…", Toast.LENGTH_SHORT).show()
        val app = applicationContext
        Thread {
            val saved = CoverStore.importOriginal(app, uri) &&
                CoverStore.renderCover(app, CoverStore.widgetAspect(app))
            runOnUiThread {
                refreshUi()
                WidgetUpdater.updateAll(app)
                if (saved) {
                    // Directo al editor para encuadrarla a tu gusto
                    startActivity(Intent(this, CropActivity::class.java))
                } else {
                    Toast.makeText(this, "No se pudo usar esa imagen", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun resultIntent() =
        Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)

    companion object {
        private const val REQ_PICK = 42
    }
}
