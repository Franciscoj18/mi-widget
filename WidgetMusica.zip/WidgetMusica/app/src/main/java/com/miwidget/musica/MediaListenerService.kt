package com.miwidget.musica

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.service.notification.NotificationListenerService

/**
 * Android solo deja leer/controlar la música de otras apps a un "lector de notificaciones".
 * Este servicio escucha cambios de canción y de play/pausa, y mueve la barra de progreso.
 */
class MediaListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var sessionManager: MediaSessionManager? = null
    private val watched = mutableListOf<MediaController>()
    private var ticking = false

    private val refreshRunnable = Runnable {
        WidgetUpdater.updateAll(applicationContext)
        ensureTicking()
    }

    /** Mientras suena música, avanza la barra en pasos pequeños (cada 5 s con la pantalla apagada). */
    private val tickRunnable = object : Runnable {
        override fun run() {
            val c = WidgetUpdater.findController(applicationContext)
            if (!WidgetUpdater.isPlaying(c)) {
                ticking = false
                return
            }
            val screenOn = getSystemService(PowerManager::class.java)?.isInteractive != false
            if (screenOn) WidgetUpdater.updateProgress(applicationContext, c)
            // Pantalla encendida: pasos pequeños y frecuentes (avance suave).
            // Apagada: cada 5 s, para no gastar batería.
            val next = if (screenOn) WidgetUpdater.tickIntervalMs(applicationContext, c) else 5000L
            handler.postDelayed(this, next)
        }
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = scheduleRefresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = scheduleRefresh()
        override fun onSessionDestroyed() = scheduleRefresh()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            watch(controllers ?: emptyList())
            scheduleRefresh()
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val msm = getSystemService(MediaSessionManager::class.java) ?: return
        sessionManager = msm
        val me = ComponentName(this, MediaListenerService::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, me)
            watch(msm.getActiveSessions(me))
        } catch (e: SecurityException) {
            // Todavía sin permiso
        }
        scheduleRefresh()
    }

    override fun onListenerDisconnected() {
        handler.removeCallbacks(tickRunnable)
        ticking = false
        unwatchAll()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) { }
        super.onListenerDisconnected()
    }

    private fun watch(controllers: List<MediaController>) {
        unwatchAll()
        for (c in controllers) {
            c.registerCallback(controllerCallback, handler)
            watched.add(c)
        }
    }

    private fun unwatchAll() {
        for (c in watched) {
            try { c.unregisterCallback(controllerCallback) } catch (e: Exception) { }
        }
        watched.clear()
    }

    private fun ensureTicking() {
        if (ticking) return
        ticking = true
        handler.postDelayed(tickRunnable, 1000L)
    }

    /** Agrupa muchos cambios seguidos en una sola actualización del widget. */
    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 150)
    }

    companion object {
        /** Si el sistema cerró el servicio (pasa en XOS), le pide que lo vuelva a conectar. */
        fun rebindIfNeeded(ctx: Context) {
            if (!WidgetUpdater.hasNotificationAccess(ctx)) return
            try {
                NotificationListenerService.requestRebind(
                    ComponentName(ctx, MediaListenerService::class.java)
                )
            } catch (e: Exception) { }
        }
    }
}
