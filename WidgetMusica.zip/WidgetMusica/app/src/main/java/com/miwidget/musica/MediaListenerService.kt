package com.miwidget.musica

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService

/**
 * Android solo deja leer/controlar la música de otras apps a un "lector de notificaciones".
 * Este servicio escucha cambios de canción y de play/pausa y actualiza el widget al instante.
 */
class MediaListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var sessionManager: MediaSessionManager? = null
    private val watched = mutableListOf<MediaController>()

    private val refreshRunnable = Runnable { WidgetUpdater.updateAll(applicationContext) }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = scheduleRefresh()
        override fun onPlaybackStateChanged(state: PlaybackState?) = scheduleRefresh()
        override fun onSessionDestroyed() = scheduleRefresh()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            watch(controllers ?: emptyList())
            scheduleRefresh()
        }

    override fun onListenerConnected() {
        super.onListenerConnected()
        val msm = getSystemService(MediaSessionManager::class.java) ?: return
        sessionManager = msm
        val me = ComponentName(this, MediaListenerService::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, me)
            watch(msm.getActiveSessions(me))
        } catch (e: SecurityException) {
            // Todavía sin permiso
        }
        scheduleRefresh()
    }

    override fun onListenerDisconnected() {
        unwatchAll()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) { }
        super.onListenerDisconnected()
    }

    private fun watch(controllers: List<MediaController>) {
        unwatchAll()
        for (c in controllers) {
            c.registerCallback(controllerCallback, handler)
            watched.add(c)
        }
    }

    private fun unwatchAll() {
        for (c in watched) {
            try { c.unregisterCallback(controllerCallback) } catch (e: Exception) { }
        }
        watched.clear()
    }

    /** Agrupa muchos cambios seguidos en una sola actualización del widget. */
    private fun scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable)
        handler.postDelayed(refreshRunnable, 150)
    }

    companion object {
        /** Si el sistema cerró el servicio (pasa en XOS), le pide que lo vuelva a conectar. */
        fun rebindIfNeeded(ctx: Context) {
            if (!WidgetUpdater.hasNotificationAccess(ctx)) return
            try {
                NotificationListenerService.requestRebind(ComponentName(ctx, MediaListenerService::class.java))
            } catch (e: Exception) { }
        }
    }
}
