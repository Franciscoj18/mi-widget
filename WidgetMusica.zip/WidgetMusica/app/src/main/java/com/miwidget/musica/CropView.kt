package com.miwidget.musica

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View

/**
 * Vista para encuadrar la imagen: arrastra para mover, pellizca para hacer zoom.
 * El marco tiene la misma forma que tu widget.
 */
class CropView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    var bitmap: Bitmap? = null
        set(value) { field = value; invalidate() }

    var aspect = 2f
        set(value) { field = value; invalidate() }

    var brightness = 1f
        set(value) {
            field = value
            imagePaint = CoverStore.brightnessPaint(value)
            invalidate()
        }

    /** Curvatura del marco como fracción del ancho (para que se vea igual que el widget). */
    var cornerFraction = 0.09f
        set(value) { field = value; invalidate() }

    var cx = 0.5f
        private set
    var cy = 0.5f
        private set
    var zoom = 1f
        private set

    private val dp = resources.displayMetrics.density
    private var imagePaint = CoverStore.brightnessPaint(1f)
    private val dimPaint = Paint().apply { color = 0xB3000000.toInt() }
    private val scrimPaint = Paint()
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2 * dp
        color = 0xFFFFFFFF.toInt()
    }
    private val frame = RectF()

    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(1f, 6f)
                normalize()
                invalidate()
                return true
            }
        })

    fun setState(cx: Float, cy: Float, zoom: Float) {
        this.cx = cx
        this.cy = cy
        this.zoom = zoom.coerceIn(1f, 6f)
        normalize()
        invalidate()
    }

    private fun params() = CoverStore.Params(cx, cy, zoom, brightness)

    private fun currentCrop(): RectF? {
        val b = bitmap ?: return null
        return CoverStore.cropRect(b.width.toFloat(), b.height.toFloat(), aspect, params())
    }

    /** Evita que el marco se salga de la imagen. */
    private fun normalize() {
        val b = bitmap ?: return
        val r = currentCrop() ?: return
        cx = r.centerX() / b.width
        cy = r.centerY() / b.height
    }

    private fun computeFrame() {
        val pad = 12 * dp
        val availW = width - 2 * pad
        val availH = height - 2 * pad
        val fw: Float
        val fh: Float
        if (availW / availH > aspect) {
            fh = availH; fw = fh * aspect
        } else {
            fw = availW; fh = fw / aspect
        }
        val left = (width - fw) / 2
        val top = (height - fh) / 2
        frame.set(left, top, left + fw, top + fh)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width == 0 || height == 0) return
        computeFrame()
        val b = bitmap ?: return
        val r = currentCrop() ?: return
        val s = frame.width() / r.width()

        // Imagen completa, colocada para que el recorte caiga dentro del marco
        canvas.save()
        canvas.translate(frame.left - r.left * s, frame.top - r.top * s)
        canvas.scale(s, s)
        canvas.drawBitmap(b, 0f, 0f, imagePaint)
        canvas.restore()

        // Oscurece lo que queda fuera del widget
        canvas.drawRect(0f, 0f, width.toFloat(), frame.top, dimPaint)
        canvas.drawRect(0f, frame.bottom, width.toFloat(), height.toFloat(), dimPaint)
        canvas.drawRect(0f, frame.top, frame.left, frame.bottom, dimPaint)
        canvas.drawRect(frame.right, frame.top, width.toFloat(), frame.bottom, dimPaint)

        // Vista previa del degradado del widget (donde van el texto y los botones)
        scrimPaint.shader = LinearGradient(
            0f, frame.top + frame.height() * 0.3f, 0f, frame.bottom,
            0x00000000, 0xD9000000.toInt(), Shader.TileMode.CLAMP
        )
        canvas.drawRect(frame, scrimPaint)

        val corner = frame.width() * cornerFraction
        canvas.drawRoundRect(frame, corner, corner, framePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y; dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_POINTER_DOWN -> dragging = false
            MotionEvent.ACTION_MOVE -> {
                val b = bitmap
                val r = currentCrop()
                if (dragging && !scaleDetector.isInProgress && e.pointerCount == 1 && b != null && r != null) {
                    val s = frame.width() / r.width()
                    cx -= (e.x - lastX) / s / b.width
                    cy -= (e.y - lastY) / s / b.height
                    normalize()
                    invalidate()
                }
                lastX = e.x; lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // Al soltar un dedo del pellizco, seguimos arrastrando con el otro
                val remaining = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(remaining); lastY = e.getY(remaining)
                dragging = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}
