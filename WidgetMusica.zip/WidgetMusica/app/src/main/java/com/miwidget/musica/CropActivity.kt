package com.miwidget.musica

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import kotlin.math.roundToInt

/** Pantalla "Ajustar portada": mover, zoom, girar y brillo. */
class CropActivity : Activity() {

    private lateinit var crop: CropView
    private lateinit var brightnessBar: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop)

        crop = findViewById(R.id.crop_view)
        brightnessBar = findViewById(R.id.brightness)

        val original = CoverStore.loadOriginal(this)
        if (original == null) {
            Toast.makeText(this, "Primero elige una imagen", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val p = CoverStore.loadParams(this)
        crop.bitmap = original
        crop.aspect = CoverStore.widgetAspect(this)
        crop.cornerFraction = StyleStore.radiusDp(this) / CoverStore.cardWidthDp(this)
        crop.brightness = p.brightness
        crop.setState(p.cx, p.cy, p.zoom)
        brightnessBar.progress = ((p.brightness - 0.5f) * 100).roundToInt()

        brightnessBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                crop.brightness = 0.5f + progress / 100f
            }
            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })

        findViewById<Button>(R.id.btn_rotate).setOnClickListener { rotate() }

        findViewById<Button>(R.id.btn_reset).setOnClickListener {
            crop.setState(0.5f, 0.5f, 1f)
            brightnessBar.progress = 50
        }

        findViewById<Button>(R.id.btn_cancel).setOnClickListener { finish() }

        findViewById<Button>(R.id.btn_save).setOnClickListener { save() }
    }

    private fun rotate() {
        val app = applicationContext
        Thread {
            CoverStore.rotateOriginal(app)
            val rotated = CoverStore.loadOriginal(app)
            runOnUiThread {
                crop.bitmap = rotated
                crop.setState(0.5f, 0.5f, 1f)
            }
        }.start()
    }

    private fun save() {
        val app = applicationContext
        CoverStore.saveParams(app, CoverStore.Params(crop.cx, crop.cy, crop.zoom, crop.brightness))
        val aspect = crop.aspect
        Thread {
            val ok = CoverStore.renderCover(app, aspect)
            runOnUiThread {
                WidgetUpdater.invalidateCard()
                WidgetUpdater.updateAll(app)
                Toast.makeText(
                    this, if (ok) "¡Portada actualizada!" else "No se pudo guardar",
                    Toast.LENGTH_SHORT
                ).show()
                setResult(RESULT_OK)
                finish()
            }
        }.start()
    }
}
