package com.miwidget.musica

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

/** El widget de la pantalla de inicio. */
class MusicWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetUpdater.updateAll(context)
        MediaListenerService.rebindIfNeeded(context)
    }

    override fun onEnabled(context: Context) {
        MediaListenerService.rebindIfNeeded(context)
    }

    /** Si cambias el tamaño del widget, recortamos de nuevo tu imagen a la nueva forma. */
    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        val app = context.applicationContext
        val pending = goAsync()
        Thread {
            try {
                if (CoverStore.hasOriginal(app)) {
                    CoverStore.renderCover(app, CoverStore.widgetAspect(app))
                }
                WidgetUpdater.updateAll(app)
            } finally {
                pending.finish()
            }
        }.start()
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (action == WidgetUpdater.ACTION_PREV ||
            action == WidgetUpdater.ACTION_PLAY_PAUSE ||
            action == WidgetUpdater.ACTION_NEXT
        ) {
            val app = context.applicationContext
            WidgetUpdater.handleAction(app, action)
            // Damos un momento a YouTube Music para cambiar de estado y redibujamos
            val pending = goAsync()
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    WidgetUpdater.updateAll(app)
                } finally {
                    pending.finish()
                }
            }, 500)
        }
    }
}
