plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.miwidget.musica"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.miwidget.musica"
        minSdk = 28
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }

    // Firma fija: así las próximas versiones se instalan encima sin desinstalar
    signingConfigs {
        create("widget") {
            storeFile = file("widget.keystore")
            storePassword = "android"
            keyAlias = "widget"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("widget")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("widget")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias extra: solo APIs del sistema Android.
